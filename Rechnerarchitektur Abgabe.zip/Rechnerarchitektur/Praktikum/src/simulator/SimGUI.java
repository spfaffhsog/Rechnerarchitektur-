package simulator;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

@SuppressWarnings("serial")
public class SimGUI extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable registerTable;
	private JTable stackTable;
	private JTable SFRTable;
	private DefaultTableModel model;
	private DefaultTableModel registerModel;
	private DefaultTableModel stackModel;
	private DefaultTableModel SFRModel;
	private JScrollPane scrollPane;
	private JScrollPane registerScrollPane;
	private JScrollPane stackScrollPane;
	private JScrollPane SFRScrollPane;
	private Set<Integer> highlightRows;
	private Set<Integer> breakpoints;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SimGUI frame = new SimGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	private ProgramRunner currentRunner;
	static int counter = 0;
	public SimGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1380, 593);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		highlightRows = new HashSet<>();
		breakpoints = new HashSet<>();
		contentPane.setLayout(null);
		JPanel RA = new JPanel();
		RA.setBounds(1058, 91, 298, 161);
		contentPane.add(RA);
		RA.setLayout(null);
		
		JCheckBox[] checkBoxes = new JCheckBox[8];
		for (int i = 0; i < checkBoxes.length; i++) {
			checkBoxes[i] = new JCheckBox("");
			checkBoxes[i].setBounds(6 + i * 23, 15, 21, 21);
			RA.add(checkBoxes[i]);
			int index = i;
			
			// Hinzufügen des ItemListeners
			checkBoxes[i].addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					JCheckBox source = (JCheckBox) e.getSource();
					
					
					if (source.isSelected() == true) {
						PICSimulator.ram.set(5, PICSimulator.ram.get(5) | (0b10000000 >> index));
						updateRegisterTable();
						
						if (((PICSimulator.ram.get(0x81) & 0b00100000) >> 5) == 1) {
							if (((PICSimulator.ram.get(0x81) & 0b00010000) >> 4) == 0) {
								if ((PICSimulator.ram.get(0x81) & 0b00000001) == 1) {
									counter++;
									if (counter % 4 == 0) {
										PICSimulator.ram.set(0x01, (PICSimulator.ram.get(0x01) + 1));
										
									}
									
								} else {
									
									PICSimulator.ram.set(0x01, (PICSimulator.ram.get(0x01) + 1));
									
									
								}
								
							}
						}
						
					} else {
						PICSimulator.ram.set(5, PICSimulator.ram.get(5) & (0b01111111 >> index));
						updateRegisterTable();
						
						if (((PICSimulator.ram.get(0x81) & 0b00100000) >> 5) == 1) {
							if (((PICSimulator.ram.get(0x81) & 0b00010000) >> 4) == 1) {
								
								if ((PICSimulator.ram.get(0x81) & 0b00000001) == 1) {
									counter++;
									if (counter % 4 == 0) {
										PICSimulator.ram.set(0x01, (PICSimulator.ram.get(0x01) + 1));
										
									}
									
								} else {
									
									PICSimulator.ram.set(0x01, (PICSimulator.ram.get(0x01) + 1));
									
								}
							}
						}
						
					}
				}
			});

		}

		JLabel lblNewLabel = new JLabel("7");
		lblNewLabel.setBounds(13, 0, 14, 13);
		RA.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("6");
		lblNewLabel_1.setBounds(36, 0, 14, 13);
		RA.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("5");
		lblNewLabel_2.setBounds(59, 0, 14, 13);
		RA.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("4");
		lblNewLabel_3.setBounds(82, 0, 14, 13);
		RA.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("3");
		lblNewLabel_4.setBounds(106, 0, 14, 13);
		RA.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("2");
		lblNewLabel_5.setBounds(128, 0, 14, 13);
		RA.add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("1");
		lblNewLabel_6.setBounds(151, 0, 14, 13);
		RA.add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("0");
		lblNewLabel_7.setBounds(178, 0, 14, 13);
		RA.add(lblNewLabel_7);
		
		
		JCheckBox[] checkBoxesB = new JCheckBox[8];
		for (int i = 0; i < checkBoxesB.length; i++) {
			checkBoxesB[i] = new JCheckBox("");
			checkBoxesB[i].setBounds(6 + i * 23, 75, 21, 21);
			RA.add(checkBoxesB[i]);
			
			int index = i;
			checkBoxesB[0].setSelected(true);
			// Hinzufügen des ItemListeners
			checkBoxesB[i].addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent e) {
					JCheckBox source = (JCheckBox) e.getSource();
					
					
					if (source.isSelected() == true) {
						PICSimulator.ram.set(6, PICSimulator.ram.get(6) | (0b10000000 >> index));
						updateRegisterTable();
						
						if (((PICSimulator.ram.get(0x0B) & 0b00010000) >> 4) == 1) {
							if (((PICSimulator.ram.get(0x81) & 0b00010000) >> 4) == 0) {
								if ((PICSimulator.ram.get(0x81) & 0b00000001) == 1) {
									counter++;
									if (counter % 4 == 0) {
										PICSimulator.ram.set(0x01, (PICSimulator.ram.get(0x01) + 1));
										
									}
									
								} else {
									
									PICSimulator.ram.set(0x01, (PICSimulator.ram.get(0x01) + 1));
									
									
								}
								
							}
						}
						
					} else {
						PICSimulator.ram.set(6, PICSimulator.ram.get(6) & (0b01111111 >> index));
						updateRegisterTable();
						
						if (((PICSimulator.ram.get(0x0B) & 0b00010000) >> 4) == 1) {
							if (((PICSimulator.ram.get(0x81) & 0b00010000) >> 4) == 1) {
								
								if ((PICSimulator.ram.get(0x81) & 0b00000001) == 1) {
									counter++;
									if (counter % 4 == 0) {
										PICSimulator.ram.set(0x01, (PICSimulator.ram.get(0x01) + 1));
										
									}
									
								} else {
									
									PICSimulator.ram.set(0x01, (PICSimulator.ram.get(0x01) + 1));
									
								}
							}
						}
						
					}
				}
			});

		}
		
		JLabel lblNewLabelB = new JLabel("7");
		lblNewLabelB.setBounds(13, 50, 14, 13);
		RA.add(lblNewLabelB);

		JLabel lblNewLabel_1B = new JLabel("6");
		lblNewLabel_1B.setBounds(36, 50, 14, 13);
		RA.add(lblNewLabel_1B);

		JLabel lblNewLabel_2B = new JLabel("5");
		lblNewLabel_2B.setBounds(59, 50, 14, 13);
		RA.add(lblNewLabel_2B);

		JLabel lblNewLabel_3B = new JLabel("4");
		lblNewLabel_3B.setBounds(82, 50, 14, 13);
		RA.add(lblNewLabel_3B);

		JLabel lblNewLabel_4B = new JLabel("3");
		lblNewLabel_4B.setBounds(106, 50, 14, 13);
		RA.add(lblNewLabel_4B);

		JLabel lblNewLabel_5B = new JLabel("2");
		lblNewLabel_5B.setBounds(128, 50, 14, 13);
		RA.add(lblNewLabel_5B);

		JLabel lblNewLabel_6B = new JLabel("1");
		lblNewLabel_6B.setBounds(151, 50, 14, 13);
		RA.add(lblNewLabel_6B);

		JLabel lblNewLabel_7B = new JLabel("0");
		lblNewLabel_7B.setBounds(178, 50, 14, 13);
		RA.add(lblNewLabel_7B);
		
		JLabel wlbl = new JLabel("W: 0x00");
		wlbl.setBounds(10, 460, 52, 126);
		contentPane.add(wlbl);

		JLabel PClbl = new JLabel("PC: 0x0000");
		PClbl.setBounds(72, 460, 93, 126);
		contentPane.add(PClbl);

		JLabel PCLlbl = new JLabel("PCL: 0x00");
		PCLlbl.setBounds(148, 517, 57, 13);
		contentPane.add(PCLlbl);

		JLabel PCLATHlbl = new JLabel("PCLATH: 0x00");
		PCLATHlbl.setBounds(215, 517, 88, 13);
		contentPane.add(PCLATHlbl);

		JLabel CFlaglbl = new JLabel("C: 0");
		CFlaglbl.setBounds(313, 517, 45, 13);
		contentPane.add(CFlaglbl);

		JLabel DCFlaglbl = new JLabel("DC: 0");
		DCFlaglbl.setBounds(384, 517, 45, 13);
		contentPane.add(DCFlaglbl);

		JLabel ZFlaglbl = new JLabel("Z: 0");
		ZFlaglbl.setBounds(454, 517, 45, 13);
		contentPane.add(ZFlaglbl);

		JLabel TextZeitjlbl = new JLabel("Laufzeit:");
		TextZeitjlbl.setBounds(720, 25, 45, 13);
		contentPane.add(TextZeitjlbl);

		JLabel Zeitjlbl = new JLabel("0.00 µs");
		Zeitjlbl.setBounds(775, 25, 99, 13);
		contentPane.add(Zeitjlbl);

		JButton Runbtn = new JButton("Run");
		Runbtn.setBounds(52, 10, 86, 42);
		Runbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				currentRunner = new ProgramRunner(wlbl, PClbl, CFlaglbl, DCFlaglbl, ZFlaglbl, Zeitjlbl, PCLlbl,
						PCLATHlbl,checkBoxes,checkBoxesB);
				currentRunner.execute();
			}
		});
		contentPane.add(Runbtn);

		JButton Stopbtn = new JButton("Stop");
		Stopbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentRunner != null) {
					currentRunner.stop();
				}
			}
		});
		Stopbtn.setBounds(148, 10, 76, 42);
		contentPane.add(Stopbtn);

		JButton Stepbtn = new JButton("Step");
		Stepbtn.setBounds(234, 10, 69, 42);
		Stepbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				stepProgram(wlbl, PClbl, CFlaglbl, DCFlaglbl, ZFlaglbl, Zeitjlbl, PCLlbl, PCLATHlbl,checkBoxes,checkBoxesB);
			}
		});
		contentPane.add(Stepbtn);

		JButton Resetbtn = new JButton("Reset");
		Resetbtn.setBounds(313, 10, 73, 42);
		Resetbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				resetProgram(wlbl, PClbl);
			}
		});
		contentPane.add(Resetbtn);

		JButton ResetZeitbtn = new JButton("Reset timer");
		ResetZeitbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PICSimulator.Laufzeit = 0;
				Zeitjlbl.setText("0.00 µs");
			}
		});
		ResetZeitbtn.setBounds(896, 21, 137, 21);
		contentPane.add(ResetZeitbtn);

		JButton FileChooserbtn = new JButton("File chooser");
		FileChooserbtn.setBounds(417, 10, 174, 42);
		FileChooserbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				chooseFile();
			}
		});
		contentPane.add(FileChooserbtn);

		// Initialisierung der Registertabelle und Stacktabelle
		initializeTabbedPane();
	}

	private void chooseFile() {
		JFileChooser fileChooser = new JFileChooser();
		if (PICSimulator.ram.size() < 12) {
			PICSimulator.initialize();
		} else {
			PICSimulator.reset();
		}
		int returnValue = fileChooser.showOpenDialog(null);
		breakpoints.clear();
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			File selectedFile = fileChooser.getSelectedFile();
			try {
				BufferedReader reader = new BufferedReader(new FileReader(selectedFile));
				String line;
				model = new DefaultTableModel() {
					@Override
					public boolean isCellEditable(int row, int column) {
						return column == 1 && ((String) getValueAt(row, 0)).startsWith("0"); // Nur die
																								// Breakpoint-Spalte und
																								// nur für Zeilen, die
																								// mit 0 beginnen, sind
																								// bearbeitbar
					}
				};

				model.addColumn("Line");
				model.addColumn("BP");
				// Spalte für Breakpoints
				while ((line = reader.readLine()) != null) {
					if (line.startsWith("0")) {
						PICSimulator.PC = Integer.parseInt((line.subSequence(0, 4)).toString(), 16);
						PICSimulator.progspeicher.add(PICSimulator.PC,
								Integer.parseInt((line.subSequence(5, 9).toString()), 16));
					}
					model.addRow(new Object[] { line, false });
				}
				reader.close();
				PICSimulator.PC = 0;

				if (scrollPane != null) {
					contentPane.remove(scrollPane);
				}
				table = new JTable(model);
				scrollPane = new JScrollPane(table);

				contentPane.add(scrollPane);
				scrollPane.setBounds(50, 60, 650, 400);

				// Spaltenbreite für Breakpoints festlegen
				TableColumn breakpointColumn = table.getColumnModel().getColumn(1);
				breakpointColumn.setMaxWidth(50);
				breakpointColumn.setPreferredWidth(50);

				// Renderer für Breakpoint-Spalte
				table.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {
					@Override
					public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
							boolean isSelected, boolean hasFocus, int row, int column) {
						JCheckBox checkBox = new JCheckBox();
						checkBox.setSelected((Boolean) value);
						checkBox.setHorizontalAlignment(JLabel.CENTER);
						return checkBox;
					}
				});

				// Action Listener für Breakpoint-Spalte
				table.getColumnModel().getColumn(1).setCellEditor(new DefaultCellEditor(new JCheckBox()) {
					@Override
					public java.awt.Component getTableCellEditorComponent(JTable table, Object value,
							boolean isSelected, int row, int column) {
						JCheckBox checkBox = (JCheckBox) super.getTableCellEditorComponent(table, value, isSelected,
								row, column);
						checkBox.setSelected((Boolean) value);
						return checkBox;
					}

					@Override
					public Object getCellEditorValue() {
						int pcValue = 100;
						JCheckBox checkBox = (JCheckBox) getComponent();
						int n = table.getSelectedRow();
						String line = (String) model.getValueAt(n, 0);
						if (line.startsWith("0")) {
							pcValue = Integer.parseInt(line.substring(0, 4), 16);
						}
						if (checkBox.isSelected()) {

							breakpoints.add(pcValue);
						} else {
							breakpoints.remove(pcValue);
						}

						return checkBox.isSelected();
					}
				});

				table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
					@Override
					public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
							boolean isSelected, boolean hasFocus, int row, int column) {
						java.awt.Component comp = super.getTableCellRendererComponent(table, value, isSelected,
								hasFocus, row, column);
						if (highlightRows.contains(row)) {
							comp.setBackground(Color.YELLOW);
						} else {
							comp.setBackground(Color.WHITE);
						}
						return comp;
					}
				});

				contentPane.revalidate();
				contentPane.repaint();
			} catch (IOException ex) {
				ex.printStackTrace();
				JOptionPane.showMessageDialog(null, "Error reading file.", "Error", JOptionPane.ERROR_MESSAGE);
			}
			updateTableHighlighting();
			updateRegisterTable();
		}

		PICSimulator.PC = 0;
	}

	private void initializeTabbedPane() {
		JTabbedPane tabbedPane = new JTabbedPane();
		tabbedPane.setBounds(720, 60, 300, 400);
		contentPane.add(tabbedPane);

		initializeRegisterTable(tabbedPane);
		initializeStackTable(tabbedPane);
		initializeSFRTable(tabbedPane);

	}

	private void initializeRegisterTable(JTabbedPane tabbedPane) {
		registerModel = new DefaultTableModel();
		registerModel.addColumn("Address");
		registerModel.addColumn("Value (HEX)");
		registerModel.addColumn("Value (Binary)");

		for (int i = 0x0C; i <= 0x4F; i++) {
			String address = String.format("0x%02X", i);
			String valueHex = "0x00";
			String valueBin = "00000000";
			registerModel.addRow(new Object[] { address, valueHex, valueBin });
		}
		for (int i = 0x8C; i <= 0xCF; i++) {
			String address = String.format("0x%02X", i);
			String valueHex = "0x00";
			String valueBin = "00000000";
			registerModel.addRow(new Object[] { address, valueHex, valueBin });
		}

		registerTable = new JTable(registerModel);
		registerScrollPane = new JScrollPane(registerTable);
		tabbedPane.addTab("GPR", registerScrollPane);

		// Registertabelle zentrieren
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for (int i = 0; i < registerTable.getColumnCount(); i++) {
			registerTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
		}
	}

	private void initializeStackTable(JTabbedPane tabbedPane) {
		stackModel = new DefaultTableModel();
		stackModel.addColumn("Address");
		stackModel.addColumn("Value (HEX)");

		for (int i = 0; i < 8; i++) {
			String address = String.format("%02X", i);
			String value = "00"; // Initialwert für jedes Stackelement
			stackModel.addRow(new Object[] { address, value });
		}

		stackTable = new JTable(stackModel);
		stackScrollPane = new JScrollPane(stackTable);
		tabbedPane.addTab("Stack", stackScrollPane);

		// Stacktabelle zentrieren
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for (int i = 0; i < stackTable.getColumnCount(); i++) {
			stackTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
		}
	}

	private void initializeSFRTable(JTabbedPane tabbedPane) {
		SFRModel = new DefaultTableModel();
		SFRModel.addColumn("Address");
		SFRModel.addColumn("Value (HEX)");
		SFRModel.addColumn("Value (Binary)");

		for (int i = 0x00; i <= 0x0B; i++) {
			String address = String.format("0x%02X", i);
			String valueHex = "0x00";
			String valueBin = "00000000";
			SFRModel.addRow(new Object[] { address, valueHex, valueBin });
		}
		for (int i = 0x80; i <= 0x8B; i++) {
			String address = String.format("0x%02X", i);
			String valueHex = "0x00";
			String valueBin = "00000000";
			SFRModel.addRow(new Object[] { address, valueHex, valueBin });
		}

		SFRTable = new JTable(SFRModel);
		SFRScrollPane = new JScrollPane(SFRTable);
		tabbedPane.addTab("SFR", SFRScrollPane);

		// Registertabelle zentrieren
		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
		centerRenderer.setHorizontalAlignment(JLabel.CENTER);
		for (int i = 0; i < registerTable.getColumnCount(); i++) {
			registerTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
		}
	}



	private void updateRegisterTable() {
		for (int i = 0; i < registerModel.getRowCount(); i++) {
			String addressStr = (String) registerModel.getValueAt(i, 0);
			int address = Integer.parseInt(addressStr.substring(2), 16);

			int value = PICSimulator.ram.get(address);
			String valueHex = String.format("0x%02X", value);
			String valueBin = String.format("%8s", Integer.toBinaryString(value)).replace(' ', '0');

			registerModel.setValueAt(valueHex, i, 1);
			registerModel.setValueAt(valueBin, i, 2);

		}
		if (PICSimulator.stack.size() == 0) {
			stackModel.setValueAt("0x00", 0, 1);
		}
		for (int i = 0; i < PICSimulator.stack.size(); i++) {
			String addressStr = (String) stackModel.getValueAt(i, 0);
			int address = Integer.parseInt(addressStr, 16);

			int value = PICSimulator.stack.get(address);
			String valueHex = String.format("0x%02X", value);

			stackModel.setValueAt(valueHex, i, 1);

		}
		for (int i = 0; i < SFRModel.getRowCount(); i++) {
			String addressStr = (String) SFRModel.getValueAt(i, 0);
			int address = Integer.parseInt(addressStr.substring(2), 16);

			int value = PICSimulator.ram.get(address);
			String valueHex = String.format("0x%02X", value);
			String valueBin = String.format("%8s", Integer.toBinaryString(value)).replace(' ', '0');

			SFRModel.setValueAt(valueHex, i, 1);
			SFRModel.setValueAt(valueBin, i, 2);

		}

	}

	private class ProgramRunner extends SwingWorker<Void, Void> {
		private JLabel wlbl;
		private JLabel PClbl;
		private JLabel CFlaglbl;
		private JLabel DCFlaglbl;
		private JLabel ZFlaglbl;
		private JLabel Zeitlbl;
		private JLabel PCLlbl;
		private JLabel PCLATHlbl;
		private JCheckBox[] checkBoxes;
		private JCheckBox[] checkBoxesB;
		private volatile boolean running = true; // Flag to control the loop

		public ProgramRunner(JLabel wlbl, JLabel PClbl, JLabel CFlaglbl, JLabel DCFlaglbl, JLabel ZFlaglbl,
				JLabel Zeitlbl, JLabel PCLlbl, JLabel PCLATHlbl,JCheckBox[] checkBoxes,JCheckBox[] checkBoxesB) {
			this.wlbl = wlbl;
			this.PClbl = PClbl;
			this.CFlaglbl = CFlaglbl;
			this.DCFlaglbl = DCFlaglbl;
			this.ZFlaglbl = ZFlaglbl;
			this.Zeitlbl = Zeitlbl;
			this.PCLlbl = PCLlbl;
			this.PCLATHlbl = PCLATHlbl;
			this.checkBoxes=checkBoxes;
			this.checkBoxesB=checkBoxesB;
		}

		private void updateStatus(JLabel wlbl, JLabel PClbl, JLabel CFlaglbl, JLabel DCFlaglbl, JLabel ZFlaglbl,
				JLabel Zeitlbl, JLabel PCLlbl, JLabel PCLATHlbl) {
			wlbl.setText("W: 0x" + String.format("%02X", PICSimulator.w));
			PClbl.setText("PC: 0x" + String.format("%04X", PICSimulator.PC));
			CFlaglbl.setText("C: " + String.format("%01X", PICSimulator.ram.get(3) & 0b00000001));
			DCFlaglbl.setText("DC: " + String.format("%01X", (PICSimulator.ram.get(3) & 0b00000010) >> 1));
			ZFlaglbl.setText("Z: " + String.format("%01X", (PICSimulator.ram.get(3) & 0b00000100) >> 2));
			Zeitlbl.setText(String.format("%d", PICSimulator.Laufzeit) + ".00µs");
			PCLlbl.setText("PCL: " + String.format("%02X", PICSimulator.ram.get(2)));
			PCLATHlbl.setText("PCLATH: " + String.format("%02X", PICSimulator.ram.get(10)));
		}

		@Override
		protected Void doInBackground() throws Exception {
			PICSimulator.initialize();

			while (running && PICSimulator.PC < PICSimulator.progspeicher.size()) {

				if (breakpoints.contains(PICSimulator.PC)) {
					break; // Halt the execution at the breakpoint
				}

				PICSimulator.Befehlsdecoder();
				
				if((PICSimulator.ram.get(0x85)&1)==0) {
					if((PICSimulator.ram.get(5)&1)==1) {
						checkBoxes[7].setSelected(true);
					}else {
						checkBoxes[7].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x85)&0b00000010)>>1)==0) {
					if(((PICSimulator.ram.get(5)&0b00000010)>>1)==1) {
						checkBoxes[6].setSelected(true);
					}else {
						checkBoxes[6].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x85)&0b00000100)>>2)==0) {
					if(((PICSimulator.ram.get(5)&0b00000100)>>2)==1) {
						checkBoxes[5].setSelected(true);
					}else {
						checkBoxes[5].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x85)&0b00001000)>>3)==0) {
					if(((PICSimulator.ram.get(5)&0b00001000)>>3)==1) {
						checkBoxes[4].setSelected(true);
					}else {
						checkBoxes[4].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x85)&0b00010000)>>4)==0) {
					if(((PICSimulator.ram.get(5)&0b00010000)>>4)==1) {
						checkBoxes[3].setSelected(true);
					}else {
						checkBoxes[3].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x85)&0b00100000)>>5)==0) {
					if(((PICSimulator.ram.get(5)&0b00100000)>>5)==1) {
						checkBoxes[2].setSelected(true);
					}else {
						checkBoxes[2].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x85)&0b01000000)>>6)==0){
					if(((PICSimulator.ram.get(5)&0b01000000)>>6)==1){
						checkBoxes[1].setSelected(true);
					}else {
						checkBoxes[1].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x85)&0b10000000)>>7)==0) {
					if(((PICSimulator.ram.get(5)&0b10000000)>>7)==1) {
						checkBoxes[0].setSelected(true);
					}else {
						checkBoxes[0].setSelected(false);
					}}
					
					if((PICSimulator.ram.get(0x86)&1)==0) {
					if((PICSimulator.ram.get(6)&1)==1) {
						checkBoxesB[7].setSelected(true);
					}else {
						checkBoxesB[7].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x86)&0b00000010)>>1)==0) {
					if(((PICSimulator.ram.get(6)&0b00000010)>>1)==1) {
						checkBoxesB[6].setSelected(true);
					}else {
						checkBoxesB[6].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x86)&0b00000100)>>2)==0) {
					if(((PICSimulator.ram.get(6)&0b00000100)>>2)==1) {
						checkBoxesB[5].setSelected(true);
					}else {
						checkBoxesB[5].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x86)&0b00001000)>>3)==0) {
					if(((PICSimulator.ram.get(6)&0b00001000)>>3)==1) {
						checkBoxesB[4].setSelected(true);
					}else {
						checkBoxesB[4].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x86)&0b00010000)>>4)==0) {
					if(((PICSimulator.ram.get(6)&0b00010000)>>4)==1) {
						checkBoxesB[3].setSelected(true);
					}else {
						checkBoxesB[3].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x86)&0b00100000)>>5)==0) {
					if(((PICSimulator.ram.get(6)&0b00100000)>>5)==1) {
						checkBoxesB[2].setSelected(true);
					}else {
						checkBoxesB[2].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x86)&0b01000000)>>6)==0){
					if(((PICSimulator.ram.get(6)&0b01000000)>>6)==1){
						checkBoxesB[1].setSelected(true);
					}else {
						checkBoxesB[1].setSelected(false);
					}}
					if(((PICSimulator.ram.get(0x86)&0b10000000)>>7)==0) {
					if(((PICSimulator.ram.get(6)&0b10000000)>>7)==1) {
						checkBoxesB[0].setSelected(true);
					}else {
						checkBoxesB[0].setSelected(false);
					}}
				
				updateStatus(wlbl, PClbl, CFlaglbl, DCFlaglbl, ZFlaglbl, Zeitlbl, PCLlbl, PCLATHlbl);
				TimeUnit.MILLISECONDS.sleep(5); // adjust the sleep time as necessary
				publish();
			}
			return null;
		}

		@Override
		protected void process(List<Void> chunks) {
			updateTableHighlighting();
			updateRegisterTable();

		}

		public void stop() {
			running = false; // Method to stop the loop
		}
	}

	private void stepProgram(JLabel wlbl, JLabel PClbl, JLabel CFlaglbl, JLabel DCFlaglbl, JLabel ZFlaglbl,
			JLabel Zeitlbl, JLabel PCLlbl, JLabel PCLATHlbl,JCheckBox[] checkBoxes,JCheckBox[] checkBoxesB) {
		PICSimulator.initialize();

		PICSimulator.Befehlsdecoder();
		wlbl.setText("W: 0x" + String.format("%02X", PICSimulator.w));
		PClbl.setText("PC: 0x" + String.format("%04X", PICSimulator.PC));
		CFlaglbl.setText("C: " + String.format("%01X", PICSimulator.ram.get(3) & 0b00000001));
		DCFlaglbl.setText("DC: " + String.format("%01X", (PICSimulator.ram.get(3) & 0b00000010) >> 1));
		ZFlaglbl.setText("Z: " + String.format("%01X", (PICSimulator.ram.get(3) & 0b00000100) >> 2));
		ZFlaglbl.setText("Z: " + String.format("%01X", (PICSimulator.ram.get(3) & 0b00000100) >> 2));
		Zeitlbl.setText(String.format("%d", PICSimulator.Laufzeit) + ".00µs");
		PCLlbl.setText("PCL: " + String.format("%02X", PICSimulator.ram.get(2)));
		PCLATHlbl.setText("PCLATH: " + String.format("%02X", PICSimulator.ram.get(10)));
		updateRegisterTable();
		if((PICSimulator.ram.get(0x85)&1)==0) {
		if((PICSimulator.ram.get(5)&1)==1) {
			checkBoxes[7].setSelected(true);
		}else {
			checkBoxes[7].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x85)&0b00000010)>>1)==0) {
		if(((PICSimulator.ram.get(5)&0b00000010)>>1)==1) {
			checkBoxes[6].setSelected(true);
		}else {
			checkBoxes[6].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x85)&0b00000100)>>2)==0) {
		if(((PICSimulator.ram.get(5)&0b00000100)>>2)==1) {
			checkBoxes[5].setSelected(true);
		}else {
			checkBoxes[5].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x85)&0b00001000)>>3)==0) {
		if(((PICSimulator.ram.get(5)&0b00001000)>>3)==1) {
			checkBoxes[4].setSelected(true);
		}else {
			checkBoxes[4].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x85)&0b00010000)>>4)==0) {
		if(((PICSimulator.ram.get(5)&0b00010000)>>4)==1) {
			checkBoxes[3].setSelected(true);
		}else {
			checkBoxes[3].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x85)&0b00100000)>>5)==0) {
		if(((PICSimulator.ram.get(5)&0b00100000)>>5)==1) {
			checkBoxes[2].setSelected(true);
		}else {
			checkBoxes[2].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x85)&0b01000000)>>6)==0){
		if(((PICSimulator.ram.get(5)&0b01000000)>>6)==1){
			checkBoxes[1].setSelected(true);
		}else {
			checkBoxes[1].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x85)&0b10000000)>>7)==0) {
		if(((PICSimulator.ram.get(5)&0b10000000)>>7)==1) {
			checkBoxes[0].setSelected(true);
		}else {
			checkBoxes[0].setSelected(false);
		}}
		
		if((PICSimulator.ram.get(0x86)&1)==0) {
		if((PICSimulator.ram.get(6)&1)==1) {
			checkBoxesB[7].setSelected(true);
		}else {
			checkBoxesB[7].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x86)&0b00000010)>>1)==0) {
		if(((PICSimulator.ram.get(6)&0b00000010)>>1)==1) {
			checkBoxesB[6].setSelected(true);
		}else {
			checkBoxesB[6].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x86)&0b00000100)>>2)==0) {
		if(((PICSimulator.ram.get(6)&0b00000100)>>2)==1) {
			checkBoxesB[5].setSelected(true);
		}else {
			checkBoxesB[5].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x86)&0b00001000)>>3)==0) {
		if(((PICSimulator.ram.get(6)&0b00001000)>>3)==1) {
			checkBoxesB[4].setSelected(true);
		}else {
			checkBoxesB[4].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x86)&0b00010000)>>4)==0) {
		if(((PICSimulator.ram.get(6)&0b00010000)>>4)==1) {
			checkBoxesB[3].setSelected(true);
		}else {
			checkBoxesB[3].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x86)&0b00100000)>>5)==0) {
		if(((PICSimulator.ram.get(6)&0b00100000)>>5)==1) {
			checkBoxesB[2].setSelected(true);
		}else {
			checkBoxesB[2].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x86)&0b01000000)>>6)==0){
		if(((PICSimulator.ram.get(6)&0b01000000)>>6)==1){
			checkBoxesB[1].setSelected(true);
		}else {
			checkBoxesB[1].setSelected(false);
		}}
		if(((PICSimulator.ram.get(0x86)&0b10000000)>>7)==0) {
		if(((PICSimulator.ram.get(6)&0b10000000)>>7)==1) {
			checkBoxesB[0].setSelected(true);
		}else {
			checkBoxesB[0].setSelected(false);
		}}
		updateTableHighlighting();
	}

	private void resetProgram(JLabel wlbl, JLabel PClbl) {
		PICSimulator.w = 0;
		PICSimulator.PC = 0;
		wlbl.setText("W: 0x" + String.format("%02X", PICSimulator.w));
		PClbl.setText("PC: 0x" + String.format("%04X", PICSimulator.PC));
		highlightRows.clear();
		updateTableHighlighting();
		updateRegisterTable();
		if (table != null) {
			table.repaint();
		}
	}

	private void updateTableHighlighting() {
		highlightRows.clear();
		for (int i = 0; i < model.getRowCount(); i++) {
			String line = (String) model.getValueAt(i, 0);
			if (line.startsWith("0")) {
				int pcValue = Integer.parseInt(line.substring(0, 4), 16);
				if (pcValue == PICSimulator.PC) {
					highlightRows.add(i);
				}
			}
		}
		if (table != null) {
			table.repaint();
		}
	}
}
