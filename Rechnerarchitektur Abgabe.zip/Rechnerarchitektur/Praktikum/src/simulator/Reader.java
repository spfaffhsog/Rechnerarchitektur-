package simulator;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Reader{
 
    public static void ladeDatei(String datName) {

        File file = new File(datName);

        if (!file.canRead() || !file.isFile())
            System.exit(0);

            BufferedReader in = null;
        try {
            in = new BufferedReader(new FileReader(datName));
            String zeile = null;
            while ((zeile = in.readLine()) != null) {
            	if (zeile.startsWith("0"))
                System.out.println(zeile.subSequence(0, 9));
                         }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (in != null)
                try {
                    in.close();
                } catch (IOException e) {
                }
        }
    }

    public static void main(String[] args) {
       ladeDatei("D:\\Rechnerarchitektur\\TPicSim1.LST");
    	
    }
}