package simulator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class PICSimulator {
	static List<Integer> progspeicher = new ArrayList<Integer>(1024);
	static List<Integer> ram = new ArrayList<Integer>(256);

	static List<Integer> stack = new ArrayList<Integer>(8);

	static int w;
	static int Laufzeit = 0;
	static int flag=0;
	static int PC = 0x0000;
	static int Laufzeitlast=0;
	static int befehl;
	static int result = 0x0000;
	static int PCMAX = 0;
	static int RP1=0;
	static int timer0;

	public void Programm() {
		if (PC == 0x3FF) {
			PC = 0x0000;
		}
	}

	public static void reset() {
		timer0=ram.get(1);
		ram.clear();
		stack.clear();
		initialize();
	}

	public static void ladeDatei(String datName) {

		File file = new File(datName);

		if (!file.canRead() || !file.isFile())
			System.exit(0);

		BufferedReader in = null;
		try {
			in = new BufferedReader(new FileReader(datName));
			String zeile = null;
			while ((zeile = in.readLine()) != null) {
				if (zeile.startsWith("0")) {

					PC = Integer.parseInt((zeile.subSequence(0, 4)).toString(), 16);

					progspeicher.add(PC, Integer.parseInt((zeile.subSequence(5, 9).toString()), 16));

					PCMAX++;

				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (in != null)
				try {
					in.close();
				} catch (IOException e) {
				}
		}
	}

//	public static void main(String[] args) {
//		ladeDatei("D:\\Rechnerarchitektur\\TPicSim1.LST");
//		while (ram.size() < 12) {
//			ram.add((int) (Math.random() * 255));
//		}
//		while (ram.size() <= 256) {
//			ram.add(0);
//		}
//		Befehlsdecoder();
//
//	}
	public static void initialize() {
		if(ram.size()<12) {
		ram.add(0x0);
		ram.add(timer0);
		ram.add(0);
		ram.add((int)Math.floor(Math.random() * (31 - 24 + 1)) + 24);
		for(int i=0;i<5;i++) {
			ram.add((int)Math.random()*255);
		}
		ram.add(0);
		ram.add(0);
		ram.add(0);
		while (PICSimulator.ram.size() <= 256) {
			PICSimulator.ram.add(0);
			
		}
		ram.set(6, 0x80);
		ram.set(0x81,0xFF);
		ram.set(0x85,0x1F);
		ram.set(0x86, 0xFF);
		
	}}
	public static void interruptsEnabled() {
		
		int Prescalerrate=(ram.get(0x81)&0b00000011)+1;
		if(((ram.get(0x0B)&0b10000000)>>7)==1) {
			if(((ram.get(0x0B)&0b00100000)>>5)==1) {
				if(flag==0) {
					if(((ram.get(0x0B)&0b00100000)>>5)==1) {
						Laufzeitlast=Laufzeit-3;
						flag=1;
					}}
					if(flag==1) {
					if((Laufzeit-Laufzeitlast)>Math.pow(2, Prescalerrate)) {
					ram.set(0x01,(ram.get(0x01)+1));
					Laufzeitlast+=Math.pow(2, Prescalerrate);
					
					}
					}
					if(ram.get(1)>255) {
						ram.set(01,0);
						ram.set(0x0B,ram.get(0x0B)&0b11011111);
						ram.set(0x0B,ram.get(0x0B)|0b00000100);
						stack.add(PC);
						PC=4;
						flag=0;
					}
					
			}
			if(((ram.get(0x0B)&0b00010000)>>4)==1) {
				if((ram.get(0x06)&1)==1) {
					ram.set(0x0B,ram.get(0x0B)&0b11101111);
					ram.set(0x0B,ram.get(0x0B)|0b00000010);
					stack.add(PC);
					PC=4;
				}}
				if(((ram.get(0x0B)&0b00001000)>>3)==1) {
					if(((ram.get(0x06)&0b11110000)>>4)>1) {
						ram.set(0x0B,ram.get(0x0B)&0b11110111);
						ram.set(0x0B,ram.get(0x0B)|0b00000001);
						stack.add(PC);
						PC=4;
					}
			
		}
		
			}
			
		if(((ram.get(0x81)&0b00100000)>>5)==0) {
			if(flag==0) {
			if(ram.get(1)==1) {
				Laufzeitlast=Laufzeit-2;
				flag=1;
			}}
			if(flag==1) {
			if((Laufzeit-Laufzeitlast)>Math.pow(2, Prescalerrate)) {
			ram.set(0x01,(ram.get(0x01)+1));
			Laufzeitlast+=Math.pow(2, Prescalerrate);
			
			}
			}
			if(ram.get(1)>255) {
				ram.set(01,0);
				ram.set(0x0B,ram.get(0x0B)&0b11011111);
				flag=0;
			}
			}
	}
		
	

	public static void Befehlswahl() {
		 
		befehl = progspeicher.get(PC);
		if (befehl != 0x0100 && befehl != 0x0000 && befehl != 0x0064 && befehl != 0x0009 && befehl != 0x0008
				&& befehl != 0x0063) {
			if((befehl&0x3F00)==0x0100) {
				result=befehl&0x007F;
			}
			if (((befehl & 0x00FF) - 0x0080) == 0) {

				befehl = befehl | ram.get(4);
			}if((befehl&0x3000)==0x2000) {
				result=befehl&0x2800;
			}
			else if ((befehl & 0x3000) == 0x1000) {
				if ((befehl & 0x1f80) == 0x1000) {
					if ((befehl & 0x00FF) == 0) {
						befehl = befehl | 0x10;
					}
				} else if (((befehl & 0x00FF) - 0x0080) < 0) {

					befehl = befehl | ram.get(4);
				}
				result = befehl & 0x1C00;
			} else {
				if ((befehl & 0xF000) == 0) {

					if ((befehl & 0x0F00) == 0 || (befehl & 0x0F00) == 256) {

						result = befehl & 0x0FF0;
						if((befehl&0x3F00)==0x0100) {
							
							result=(befehl&0x0180);
						}
						if ((befehl & 0xFFF0) < 241) {
							result = 0x0080;
						}
					} else {
						result = befehl & 0x0F00;
					}

				} else {
					result = befehl & 0x3F00;
				}
			}
		} else {
			result = befehl;
		}
	}

	public static void Befehlsdecoder() {

		
		// while ((PC <=PCMAX-1)) {
		

		Befehlswahl();
		if(((ram.get(3)&0b00100000)>>5)==1) {
			RP1=0x80;
		}else {
			RP1=0x00;
		}
		switch (result) {

		case 0x0700:// addwf
			
			int wUntere = w & 0b00001111;
			int befUntere = ram.get(befehl & 0x00FF - 0x0080) & 0b00001111;
			int wObere = w & 0b11110000;
			int befObere = ram.get(befehl & 0x00FF - 0x0080) & 0b11110000;
			if (wUntere + befUntere > 15) {
				ram.set(3, ram.get(3) | 0b00000010);
			} else {
				ram.set(3, ram.get(3) & 0b11111101);
			}
			if (wObere + befObere > 256) {
				ram.set(3, ram.get(3) | 0b00000001);
			} else {
				ram.set(3, ram.get(3) & 0b11111110);
			}

			if ((befehl & 0x00F0) > 112) {
				if ((ram.get(befehl & 0x00FF - 0x0080) + w) < 256) {
					ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) + w);
				}
				if ((ram.get(befehl & 0x00FF - 0x0080) + w) > 256) {
					ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) + w - 256);
				}
				if ((ram.get(befehl & 0x00FF - 0x0080) + w) > 255)
					if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
						ram.set(3, ram.get(3) | 0b00000100);
					} else {
						ram.set(3, ram.get(3) & 0b11111011);
					}
			} else {
				if ((befehl & 0x00FF) == 0) {
					w += ram.get(ram.get(4));
				} else {
					w = ram.get(befehl & 0x00FF) + w;
				}
				if (w == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			}
			if (w < 0) {
				w = w + 256;
			}
			if (w > 255) {
				w = w - 256;
			}
			if((befehl&0x000f)==0x02) {
				PC=ram.get(2)|(ram.get(10)<<8);
				
			}
			PC++;
			
			break;
		case 0x0500:// ANDWF
			if ((befehl & 0x00F0) > 112) {
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & w);
				if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			} else {
				w = ram.get(befehl & 0x00FF) & w;
				if (w == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			}
			PC++;
			break;
		case 0x0180:// CLRF
			ram.set(befehl & 0x00FF - 0x0080, 0);
			if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			}
			PC++;
			break;
		case 0x0100:// CLRW
			w = 0;
			if (w == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			}
			PC++;
			break;
		case 0x0900:// COMF
			if ((befehl & 0x00F0) > 112) {
				ram.set(befehl & 0x00FF - 0x0080, (~ram.get(befehl & 0x00FF - 0x0080)) + 256);
				if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			} else {
				w = (~ram.get(befehl & 0x00FF) + 256);
				if (w == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			}
			PC++;
			break;
		case 0x0300:// DECF
			if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
				if ((befehl & 0x00F0) > 112) {
					ram.set(befehl & 0x00FF - 0x0080, 255);
					if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
						ram.set(3, ram.get(3) | 0b00000100);
					}
					if (ram.get(befehl & 0x00FF - 0x0080) != 0) {
						ram.set(3, ram.get(3) & 0b11111011);
					}
				} else {
					w = 255;
					if (w == 0) {
						ram.set(3, ram.get(3) | 0b00000100);
					} else {
						ram.set(3, ram.get(3) & 0b11111011);
					}
				}
			} else if (ram.get(befehl & 0x00FF - 0x0080) != 0) {
				if ((befehl & 0x00F0) > 112) {
					ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) - 1);
					if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
						ram.set(3, ram.get(3) | 0b00000100);
					}
					if (ram.get(befehl & 0x00FF - 0x0080) != 0) {
						ram.set(3, ram.get(3) & 0b11111011);
					}
				} else {
					w = (befehl & 0x00FF - 0x0080) - 1;
					if (w == 0) {
						ram.set(3, ram.get(3) | 0b00000100);
					} else {
						ram.set(3, ram.get(3) & 0b11111011);
					}
				}
			}

			PC++;
			break;
		case 0x0B00:// DECFSZ
			if ((ram.get(befehl & 0x00FF - 0x0080) - 1) == 0) {
				Laufzeit++;
				PC++;
			}
			if ((befehl & 0x00F0) > 112) {
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) - 1);
				if ((ram.get(befehl & 0x00FF - 0x0080)) < 0) {
					
					
					ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) + 256);
				}
			} else {
				w = ram.get(befehl & 0x00FF - 0x0080) - 1;
				if (w < 0) {
					w = w + 256;
				}
			}

			PC++;
			break;
		case 0x0A00:// INCF
			if (ram.get(befehl & 0x00FF - 0x0080) == 255) {
				if ((befehl & 0x00F0) > 112) {
					ram.set(befehl & 0x00FF - 0x0080, 0);
				} else {
					w = 0;
				}
			} else if ((befehl & 0x00F0) > 112) {
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) + 1);
			} else {
				w = ram.get(befehl & 0x00FF - 0x0080) + 1;

			}
			if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			} else {
				ram.set(3, ram.get(3) & 0b11111011);
			}
			if (w == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			} else {
				ram.set(3, ram.get(3) & 0b11111011);
			}
			PC++;
			break;
		case 0x0F00:// INCFSZ

			
			if ((befehl & 0x00F0) > 112) {
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) + 1);
				if ((ram.get(befehl & 0x00FF - 0x0080)) > 255) {
					ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) - 256);
					Laufzeit++;
					PC++;
				}
			} else {
				w = ram.get(befehl & 0x00FF - 0x0080) + 1;
				if (w > 255) {
					w = w - 256;
				}
				if (w == 0) {
					Laufzeit++;
					PC++;
				}
			}

			PC++;
			break;
		case 0x0400:// IORWF
			if ((befehl & 0x00F0) > 112) {
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | w);
				if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			} else {
				w = ram.get(befehl & 0x00FF - 0x0080) | w;
				if (w == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			}
			PC++;
			break;
		case 0x0800:// MOVF
			if ((befehl & 0x00F0) > 112) {
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080));
			} else {
				w = ram.get(befehl & 0x00FF - 0x0080);
			}
			if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			}
			PC++;
			break;
		case 0x0080:// MOVWF
			ram.set(befehl & 0x00FF - 0x0080+RP1, w);
			if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			} else {
				ram.set(3, ram.get(3) & 0b11111011);
			}
			PC++;

			break;
		case 0x0000:// NOP
			PC++;
			break;
		case 0x0D00:// RLF
			int temp;
			int bit7 = (ram.get(befehl & 0x00FF - 0x0080) & 0b10000000) >> 7;
			int bit0 = ram.get(3) & 0b000000001;
			temp = ram.get(befehl & 0x00FF - 0x0080) << 1;
			temp = temp | bit0;
			if (temp > 256) {
				temp = temp - 256;
			}
			if (bit7 == 1) {
				ram.set(3, ram.get(3) | bit7);
			}
			if (bit7 == 0) {
				ram.set(3, ram.get(3) & bit7);
			}
			if ((befehl & 0x00F0) > 112) {

				ram.set(befehl & 0x00FF - 0x0080, temp);
			} else {
				w = temp;
			}
			PC++;
			break;
		case 0x0C00:// RRF

			int Bit0 = (ram.get(befehl & 0x00FF - 0x0080) & 0b00000001);
			int cbit = (ram.get(3) & 0b000000001) << 7;
			temp = ram.get(befehl & 0x00FF - 0x0080) >>> 1;
			temp = temp | cbit;
			if (temp > 256) {
				temp = temp - 256;
			}
			if (Bit0 == 1) {
				ram.set(3, ram.get(3) | Bit0);
			}
			if (Bit0 == 0) {
				ram.set(3, ram.get(3) & Bit0);
			}
			if ((befehl & 0x00F0) > 112) {

				ram.set(befehl & 0x00FF - 0x0080, temp);
			} else {
				w = temp;
			}
			PC++;
			break;
		case 0x0200:// SUBWF
			int swUntere = (w - 256) & 0b00001111;
			int sbefUntere = ram.get(befehl & 0x00FF - 0x0080) & 0b00001111;
			int swObere = (w - 256) & 0b11110000;
			int sbefObere = ram.get(befehl & 0x00FF - 0x0080) & 0b11110000;

			if (swUntere <= sbefUntere) {
				ram.set(3, ram.get(3) | 0b00000010);
			} else {
				ram.set(3, ram.get(3) & 0b11111101);
			}
			if (w <= ram.get(befehl & 0x00FF - 0x0080)) {
				ram.set(3, ram.get(3) | 0b00000001);
			} else {
				ram.set(3, ram.get(3) & 0b11111110);
			}
			if ((befehl & 0x00F0) > 112) {
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) - w);
				if (ram.get(befehl & 0x00FF - 0x0080) < 0) {
					ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) + 256);
				}
				if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			} else {
				w = ram.get(befehl & 0x00FF - 0x0080) - w;
				if (w < 0) {
					w = w + 256;
				}
				if (w == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			}
			PC++;
			break;
		case 0x0E00:// SWAPF
			int hilf = 0;
			int untere = 0;
			hilf = ram.get(befehl & 0x00FF - 0x0080);
			untere = hilf & 0x0F;
			hilf = hilf >> 4;
			untere = untere << 4;
			if ((befehl & 0x00F0) > 112) {

				ram.set(befehl & 0x00FF - 0x0080, untere + hilf);
			} else {
				w = untere + hilf;
			}
			PC++;
			break;
		case 0x0600:// XORWF
			if ((befehl & 0x00F0) > 112) {

				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) ^ w);
				if (ram.get(befehl & 0x00FF - 0x0080) == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}
			} else {
				w = ram.get(befehl & 0x00FF - 0x0080) ^ w;
				if (w == 0) {
					ram.set(3, ram.get(3) | 0b00000100);
				} else {
					ram.set(3, ram.get(3) & 0b11111011);
				}

			}
			PC++;
			break;
		case 0x1000:// BCF
			switch (befehl & 0x0380) {
			case 0x0000:// 0
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & 0b11111110);
				break;
			case 0x0080:// 1
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & 0b11111101);
				break;
			case 0x0100:// 2
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & 0b11111011);
				break;
			case 0x0180:// 3
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & 0b11110111);
				break;
			case 0x0200:// 4
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & 0b11101111);
				break;
			case 0x0280:// 5
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & 0b11011111);
				break;
			case 0x0300:// 6
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & 0b10111111);
				break;
			case 0x0380:// 7
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) & 0b01111111);
				break;
			}
			PC++;
			break;
		case 0x1400:// BSF

			switch (befehl & 0x0380) {
			case 0x0000:// 0
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | 0b00000001);
				break;
			case 0x0080:// 1
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | 0b00000010);
				break;
			case 0x0100:// 2
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | 0b00000100);
				break;
			case 0x0180:// 3
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | 0b00001000);
				break;
			case 0x0200:// 4
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | 0b00010000);
				break;
			case 0x0280:// 5
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | 0b00100000);
				break;
			case 0x0300:// 6
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | 0b01000000);
				break;
			case 0x0380:// 7
				ram.set(befehl & 0x00FF - 0x0080, ram.get(befehl & 0x00FF - 0x0080) | 0b10000000);
				break;
			}
			PC++;
			break;
		case 0x1800:// BTFSC
			switch (befehl & 0x0380) {
			case 0x0000:// 0
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00000001) == 0) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0080:// 1
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00000010) == 0) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0100:// 2
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00000100) == 0) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0180:// 3
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00001000) == 0) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0200:// 4
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00010000) == 0) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0280:// 5
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00100000) == 0) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0300:// 6
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b01000000) == 0) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0380:// 7
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b10000000) == 0) {
					PC++;
					Laufzeit++;
				}
				break;
			}
			PC++;

			break;
		case 0x1C00:// BTFSS
			switch (befehl & 0x0380) {
			case 0x0000:// 0
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00000001) == 1) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0080:// 1
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00000010) > 1) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0100:// 2
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00000100) > 1) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0180:// 3
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00001000) > 1) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0200:// 4
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00010000) > 1) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0280:// 5
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b00100000) > 1) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0300:// 6
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b01000000) > 1) {
					PC++;
					Laufzeit++;
				}
				break;
			case 0x0380:// 7
				if ((ram.get(befehl & 0x00FF - 0x0080) & 0b10000000) > 1) {
					PC++;
					Laufzeit++;
				}
				break;
			}
			PC++;
			break;
		case 0x3E00:// ADDLW
			int wuntere = w & 0b00001111;
			int befuntere = ram.get(befehl & 0x00FF) & 0b00001111;
			int wobere = w & 0b11110000;
			int befobere = ram.get(befehl & 0x00FF) & 0b11110000;

			if (wuntere + befuntere > 15) {
				ram.set(3, ram.get(3) | 0b00000010);
			} else {
				ram.set(3, ram.get(3) & 0b11111101);
			}
			if (wobere + befobere > 255) {
				ram.set(3, ram.get(3) | 0b00000001);
			} else {
				ram.set(3, ram.get(3) & 0b11111110);
			}
			w = w + (befehl & 0x00FF);
			if (w < 0) {
				w = w + 256;
			}
			if (w > 255) {
				w = w - 256;
			}
			if (w == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			} else {
				ram.set(3, ram.get(3) & 0b11111011);
			}
			PC++;
			break;
		case 0x3900:// ANDLW
			w = w & (befehl & 0x00FF);
			if (w == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			} else {
				ram.set(3, ram.get(3) & 0b11111011);
			}
			PC++;
			break;
		case 0x2000://Call
			Laufzeit++;
			PC++;
			
			if (stack.size() == 7) {
				stack.add(0, PC);
			} else {
				stack.add(PC);
			}
			
			PC = befehl & 0x07FF;
			break;
		case 0x0064:// CLRWDT
			break;
		case 0x2800://Goto
			Laufzeit++;
			PC = befehl & 0x00FF;
			break;
		case 0x3800:// IORLW
			w = w | (befehl & 0x00FF);
			if (w == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			} else {
				ram.set(3, ram.get(3) & 0b11111011);
			}
			PC++;
			break;
		case 0x3000:// MOVLW
			w = befehl & 0x00FF;

			PC++;

			break;
		case 0x0009:// RETFIE
			Laufzeit++;
			PC = stack.get(stack.size() - 1);
			stack.remove(stack.size() - 1);
			ram.set(0x0B, ram.get(0x0B)&0b10000000);
			break;
		case 0x3400:// RETLW
			Laufzeit++;
			PC = stack.get(stack.size() - 1);
			stack.remove(stack.size() - 1);
			w = befehl & 0x00FF;
			break;
		case 0x0008:// RETURN
			Laufzeit++;
			PC = stack.get(stack.size() - 1);
			stack.remove(stack.size() - 1);

			break;
		case 0x0063:// SLEEP
			break;
		case 0x3C00:// SUBLW
			int swuntere = (w - 256) & 0b00001111;
			int sbefuntere = ram.get(befehl & 0x00FF);
			int swobere = (256) & 0b11110000;
			int sbefobere = ram.get(befehl & 0x00FF) & 0b11110000;

			if (sbefuntere <= swuntere) {
				ram.set(3, ram.get(3) | 0b00000010);
			} else {
				ram.set(3, ram.get(3) & 0b11111101);
			}
			if (w >= ram.get(befehl & 0x00FF)) {
				ram.set(3, ram.get(3) | 0b00000001);
			} else {
				ram.set(3, ram.get(3) & 0b11111110);
			}
			if (((befehl & 0x00FF) - w) < 0) {
				w = w + 256;
				ram.set(3, ram.get(3) & 0b11111110);
			}
			if (((befehl & 0x00FF) - w) < 0) {

			}
			w = (befehl & 0x00FF) - w;
			if (w == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			} else {
				ram.set(3, ram.get(3) & 0b11111011);
			}
			PC++;
			break;
		case 0x3A00:// XORLW
			w = w ^ (befehl & 0x00FF);
			if (w == 0) {
				ram.set(3, ram.get(3) | 0b00000100);
			} else {
				ram.set(3, ram.get(3) & 0b11111011);
			}
			PC++;
			break;
		}
		Laufzeit++;
		System.out.print(w + " " + "[" + (PC - 1) + "]" + " " + " " + ram.get(0x000C) + "  " + ram.get(0x000D) + " "
				+ (ram.get(3) & 0b00000001) + " " + (ram.get(3) & 0b00000010) + " " + (ram.get(3) & 0b00000100)
				+ " FSR:" + ram.get(4) + " F10:" + ram.get(16) + "| ");
		
			//if(((ram.get(0x0B)&0b10000000)>>7)==1) {
				interruptsEnabled();
			//}
			ram.set(2, (PC & 0b11111111));
		
		
	}

}
